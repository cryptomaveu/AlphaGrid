// Home Page placeholder
export default function Home() { return <div className="text-white">Home Page</div>; }