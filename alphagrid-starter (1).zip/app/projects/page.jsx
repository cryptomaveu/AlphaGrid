// Projects Page placeholder
export default function Projects() { return <div className="text-white">Projects Page</div>; }