// Community Page placeholder
export default function Community() { return <div className="text-white">Community Page</div>; }