// Jobs Page placeholder
export default function Jobs() { return <div className="text-white">Jobs Page</div>; }