// Alpha Drops Page placeholder
export default function AlphaDrops() { return <div className="text-white">Alpha Drops Page</div>; }