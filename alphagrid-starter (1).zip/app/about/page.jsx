// About Page placeholder
export default function About() { return <div className="text-white">About Page</div>; }