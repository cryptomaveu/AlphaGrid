// Blog News Page placeholder
export default function BlogNews() { return <div className="text-white">Blog News Page</div>; }