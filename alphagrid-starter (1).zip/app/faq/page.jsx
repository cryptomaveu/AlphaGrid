// FAQ Page placeholder
export default function FAQ() { return <div className="text-white">FAQ Page</div>; }