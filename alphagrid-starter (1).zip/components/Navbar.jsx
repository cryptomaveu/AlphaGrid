import Link from 'next/link';

const navItems = [
  { name: 'Home', href: '/' },
  { name: 'About', href: '/about' },
  { name: 'Jobs', href: '/jobs' },
  { name: 'Alpha Drops', href: '/alphadrops' },
  { name: 'Projects', href: '/projects' },
  { name: 'Blog', href: '/blognews' },
  { name: 'Community', href: '/community' },
  { name: 'FAQ', href: '/faq' }
];

export default function Navbar() {
  return (
    <nav className="bg-[#0f1b2a] px-6 py-4 flex flex-wrap justify-between items-center shadow-md">
      <Link href="/">
        <span className="text-cyan-400 text-2xl font-bold">AlphaGrid</span>
      </Link>
      <div className="flex flex-wrap gap-4 mt-2 md:mt-0 text-gray-300 text-sm">
        {navItems.map(item => (
          <Link key={item.name} href={item.href} className="hover:text-cyan-300">
            {item.name}
          </Link>
        ))}
      </div>
    </nav>
  );
}